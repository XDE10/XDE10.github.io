import re, time, logging, traceback, sys
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from artifact_types import *
from artifact_data_manager import *
from errors import *
import csv_writer, excel_writer
import logging
from selenium.common.exceptions import WebDriverException

import threading
thread_local = threading.local()

logging.basicConfig(filename='error_log.txt', level=logging.ERROR, format='%(asctime)s [%(levelname)s]: %(message)s', encoding='utf-8')

def init_thread_local():
    thread_local.global_driver = None
    thread_local.ancient_text = None
    thread_local.artifact_total_num = 0
    thread_local.artifact_num = 0
    thread_local.ancient_num = 0
    thread_local.current_artifact_type = None


def process_table(parent_div, artifact_type_number):
    if parent_div:
        tables = parent_div.find_all('div', class_='table1')
        for table in tables:
            tbody = table.find('tbody')
            if tbody:
                # 通过设置flag来跳过表头
                first_row = True
                page = extract_page_number()
                line_num = 0
                for row in tbody.find_all('tr'):
                    if first_row:  # 如果是第一行，跳过
                        first_row = False
                        continue
                    line_num += 1
                    process_artifact_row(row, page, line_num, artifact_type_number)
            else:
                print("错误: 无法找到<tbody>标签")
    else:
        print("错误: 无法找到包含文物信息的父级<div>")


def process_artifact_row(row, page, line_num, artifact_type_number):
    link = row.find("a", href=re.compile(r'/(collection|explore|ancient)/.+?/\d+'))
    href = link["href"]
    intro_url = "http://www.dpm.org.cn" + href

    # 记录当前窗口句柄
    current_window_handle = thread_local.global_driver.current_window_handle

    # 打开新标签页
    open_new_tab()
    thread_local.global_driver.get(intro_url)

    # 等待页面加载完成
    time.sleep(5)

    # 进一步提取信息，创建文物对象等
    try:
        process_artifact_details(row, page, line_num, artifact_type_number)
    except WebDriverException as e:
        # 在发生 WebDriverException 时的处理逻辑
        print(f"发生网络异常: {str(e)}，正在尝试重新访问 {intro_url}")
        retry_count = 20  # 设置最大重试次数
        current_retry = 0

        while current_retry < retry_count:
            try:
                thread_local.global_driver.get(intro_url)
                process_artifact_details(row, page, line_num, artifact_type_number)
                break  # 成功访问后跳出循环
            except WebDriverException as e:
                time.sleep(2)
                current_retry += 1

    # 关闭当前标签页
    thread_local.global_driver.close()

    # 切换回到原来的窗口句柄
    thread_local.global_driver.switch_to.window(current_window_handle)


def process_artifact_details(row, page, line_num, artifact_type_number):
    artifact_html = thread_local.global_driver.page_source
    artifact_soup = BeautifulSoup(artifact_html, "html.parser") 

    thread_local.artifact_total_num += 1
    thread_local.artifact_num += 1
    thread_local.ancient_num += 1

    # 获取文物简介并创建文物对象
    content_edit_div = artifact_soup.find('div', class_='content_edit')

    while True:
        # 重新尝试找到 content_edit_div
        content_edit_div = artifact_soup.find('div', class_='content_edit')
        if content_edit_div:
            # 找到了就跳出循环
            break
        time.sleep(2)


    if content_edit_div:
        info_tags = content_edit_div.find_all(['p', 'div'])
        info_text = extract_artifacts_info(info_tags)
        try:
            if not info_text:
                error_message = (
                    f'文物简介未找到——'
                    f'{thread_local.artifact_total_num} - {type_mapping[thread_local.current_artifact_type]}'
                    f'-{thread_local.ancient_text + "-" if  thread_local.current_artifact_type == Ancients else ""}第 {thread_local.ancient_num} 件文物-'
                    f'第 {page} 页第 {line_num} 行'
                    '\n\n' + '-'*80 + '\n'
                )  
                raise ArtifactIntroError(error_message)
        except ArtifactIntroError as e:
            # 在发生异常时的处理逻辑
            logging.error(f"以下文物在获取文物简介时发生异常", exc_info=True)
            print(f"以下文物在获取文物简介时发生异常:")
            info_text  = '文物简介异常'
        
        artifact = extract_table_info(row,  thread_local.current_artifact_type, info_text, thread_local.artifact_total_num, thread_local.artifact_num, page, line_num)

        # 把值导入古籍的分类属性 
        if thread_local.ancient_text:
            artifact.update_info("分类", thread_local.ancient_text)

        # excel_append.main(artifact_instances)
        # csv_writer.create_csv_files('output_csv', artifact_instances)

        if  thread_local.current_artifact_type != 'ancients':
            print(f'{artifact_type_number} - {type_mapping[thread_local.current_artifact_type]}-第 {thread_local.ancient_num} 件文物完成-' + artifact.info['文物名称'])
        else:
            print(f'25 - {type_mapping[thread_local.current_artifact_type]}-{thread_local.ancient_text}-第 {thread_local.ancient_num} 件文物完成-' + artifact.info['文物名称'])

    else:
        print('*'*100)
        print(artifact_soup)
        print(content_edit_div)
        print(f'文物简介未找到——'
                    f'{thread_local.artifact_total_num} - {type_mapping[thread_local.current_artifact_type]}'
                    f'-{thread_local.ancient_text + "-" if  thread_local.current_artifact_type == Ancients else ""}第 {thread_local.ancient_num} 件文物-'
                    f'第 {page} 页第 {line_num} 行'
                    '\n\n' + '-'*80 + '\n')
        print("错误: 无法找到包含文物信息的<div>标签")


def extract_artifacts_info(info_tags):
    # 处理每个 <p> 标签
    for info_tag in info_tags:
    # 删除不需要的部分
        for span in info_tag.find_all("span", class_="lemma-item"):
            span.decompose()
        for span in info_tag.find_all("span", style="display:none;"):
            span.decompose()

    # 连接所有非空 <p> 标签的文本内容
    info_text = ' '.join(p_tag.get_text(strip=True) for p_tag in info_tags if p_tag.get_text(strip=True))

    # 将英文逗号替换为中文逗号，删除所有空格
    info_text = info_text.replace(',', '，').replace(' ', '').replace('　', '').replace('\xa0', '')

    return info_text


def open_new_tab():
    thread_local.global_driver.execute_script("window.open();")
    new_tab_handle = new_tab_handle = thread_local.global_driver.window_handles[-1]
    thread_local.global_driver.switch_to.window(new_tab_handle)
    time.sleep(5)



def extract_page_number():
    # html_content = thread_local.global_driver.page_source
    # soup = BeautifulSoup(html_content, "html.parser") 
    
    # # 使用BeautifulSoup解析HTML  
    # soup = BeautifulSoup(html_content, 'html.parser')  
    
    # # 找到包含页数的<a>标签  
    # thread_local.current_page_link = soup.find('a', class_='now')  
    
    # # 提取页数  
    # page_number =  thread_local.current_page_link.text
    # return page_number 
    while True:
        html_content = thread_local.global_driver.page_source
        soup = BeautifulSoup(html_content, "html.parser") 

        # 使用BeautifulSoup解析HTML  
        soup = BeautifulSoup(html_content, 'html.parser')  

        # 找到包含页数的<a>标签  
        thread_local.current_page_link = soup.find('a', class_='now')  

        # 提取页数  
        page_number = thread_local.current_page_link.text

        # 检查是否为数字
        if page_number.isdigit():
            return page_number
        else:
            time.sleep(2)


def click_next_page():
    try:
        # 等待下一页按钮出现并可点击
        wait = WebDriverWait(thread_local.global_driver, 10)
        next_page_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[@class='next']")))
        next_page_button.click()
        
        # 等待新页面加载完成
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'table1')))
        time.sleep(5)  # 等待一段时间，确保页面完全加载

    except Exception as e:
        raise e  # 无法点击下一页按钮，直接返回

   
def jump_to_page(page):
    # 找到搜索框元素
    search_box = thread_local.global_driver.find_element(By.ID, "text_se")

    # 在搜索框中输入查询内容
    search_box.clear()
    search_box.send_keys(page)

    # 找到跳转按钮元素
    jump_button = thread_local.global_driver.find_element(By.ID, "btn_new")

    # 点击跳转按钮
    jump_button.click()

    # 等待页面加载
    time.sleep(5)


def process_ancient_link(link):
    thread_local.ancient_text = text_content_list[link_elements.index(link)]

    # 打开新的标签页
    open_new_tab()

    # 进一步处理链接
    thread_local.global_driver.get(link)

    # 等待页面加载完成
    time.sleep(5)

    while True:
        list_html = thread_local.global_driver.page_source
        list_soup = BeautifulSoup(list_html, "html.parser")
        parent_div = list_soup.find('div', class_='wrap parentsHtml')
        page = extract_page_number()

        if parent_div:
            print('*'*50 + f'第 25 个文物类型——古籍-{thread_local.ancient_text}-第 {page} 页' + '*'*50)
            process_table(parent_div, None)
            print('*'*50 + f'第 25 个文物类型——古籍-{thread_local.ancient_text}-第 {page} 页已完成' + '*'*50 + '\n')

        else:
            while True:
                time.sleep(2)
                list_html = thread_local.global_driver.page_source
                list_soup = BeautifulSoup(list_html, "html.parser")
                parent_div = list_soup.find('div', class_='wrap parentsHtml')

                if parent_div:
                    break  # 成功找到parent_div后跳出内层循环

        try:
            # 点击下一页按钮
            click_next_page()
        except Exception as e:
            break


def main(url, artifact_type_number):
    init_thread_local()

    # 创建ChromeOptions对象并启用无头模式
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--log-level=3')  # 禁用除了错误信息之外的所有日志输出

    thread_local.global_driver = webdriver.Chrome(options=chrome_options)

    # 获取默认的日志记录器  
    logger = logging.getLogger()  
    
    # 设置日志级别  
    logger.setLevel(logging.ERROR)  
    
    # 屏蔽特定的日志信息  
    logger.getChild('CONSOLE').setLevel(logging.ERROR)   
    
    match_artifact = re.search(r'/collection/(.+?)\.html|/explore/(.+?)\.html', url)
    thread_local.current_artifact_type = match_artifact.group(1) or match_artifact.group(2)

    # 获取当前窗口句柄
    current_window_handle = thread_local.global_driver.current_window_handle

    # 打开新的标签页
    open_new_tab()

    # 在新标签页中打开链接
    thread_local.global_driver.get(url)
    
    # 等待页面加载    
    time.sleep(5) 

    if  thread_local.current_artifact_type != 'ancients':
        if thread_local.current_artifact_type == 'foreigns':
            print("*"*50 + '外国文物！')
        while True:
            html = thread_local.global_driver.page_source
            soup = BeautifulSoup(html, "html.parser")

            page = extract_page_number()

            if thread_local.current_artifact_type == 'foreigns':
                page = 1
            
            print('*'*50 + f'第 {artifact_type_number} 个文物类型——{type_mapping[thread_local.current_artifact_type]}-第 {page} 页' + '*'*50 )
            parent_div = soup.find('div', class_='wrap parentsHtml')
            if parent_div:
                process_table(parent_div, artifact_type_number)
            
            else:
                while True:
                    time.sleep(3)
                    list_html = thread_local.global_driver.page_source
                    list_soup = BeautifulSoup(list_html, "html.parser")
                    parent_div = list_soup.find('div', class_='wrap parentsHtml')

                    if parent_div:
                        break  # 成功找到parent_div后跳出内层循环
                
                process_table(parent_div)
  
            print('*'*50 + f'第 {artifact_type_number} 个文物类型——{type_mapping[thread_local.current_artifact_type]}-第 {page} 页已完成' + '*'*50 + '\n')
            try:
                click_next_page()
            except Exception as e:
                print(f'第 {artifact_type_number} 个文物类型——{type_mapping[thread_local.current_artifact_type]}已全部完成——总数 {thread_local.ancient_num}')
                break
    else:
        # 查找 'text' div 元素
        text_div = thread_local.global_driver.find_element(By.CLASS_NAME, 'text')

        # 提取链接文本内容并放入列表
        global text_content_list, link_elements
        links = text_div.find_elements(By.TAG_NAME, 'a')
        text_content_list = [link.text for link in links]
    
        link_elements = [link.get_attribute('href') for link in text_div.find_elements(By.TAG_NAME, 'a')]  

        ancient_page = 0
        for link in link_elements:
            process_ancient_link(link)
            print(f'古籍-第 {ancient_page+1} 个分类-{text_content_list[ancient_page]}-已完成——总数 {thread_local.ancient_num}' + '\n')
            thread_local.ancient_num = 0
            ancient_page += 1
        print(f'第 {artifact_type_number} 个文物类型——{type_mapping[thread_local.current_artifact_type]}已全部完成——总数 {thread_local.ancient_num}' + '\n')

    thread_local.artifact_num = 0
    thread_local.global_driver.quit()


if __name__ == "__main__":
    main()


