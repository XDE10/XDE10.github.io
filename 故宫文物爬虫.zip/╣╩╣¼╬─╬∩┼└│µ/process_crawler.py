from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from artifact_types import *
import sys, logging
import time, artifact_details_crawler
import excel_writer, csv_writer
import winsound

logging.basicConfig(filename='error_log.txt', level=logging.ERROR, format='%(asctime)s [%(levelname)s]: %(message)s', encoding='utf-8')

def beep_for_duration(duration):
    end_time = time.time() + duration
    while time.time() < end_time:
        winsound.Beep(1000, 500)  # 发出频率为1000Hz，持续时间为500毫秒的蜂鸣声
        time.sleep(1)  # 等待1秒

# 创建ChromeOptions对象并启用无头模式
chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--log-level=3')  # 禁用除了错误信息之外的所有日志输出

# 创建WebDriver并指定ChromeOptions
driver = webdriver.Chrome(options=chrome_options)

# 设置全局变量 driver
artifact_details_crawler.set_global_driver(driver)

# 打开故宫博物院藏品网页
url = 'https://www.dpm.org.cn/explore/collections.html'
driver.get(url)

# 等待一段时间，确保页面加载完成
time.sleep(3)

unwanted_urls = [  
    'https://www.dpm.org.cn/shuziduobaoge.html',  
    'https://www.dpm.org.cn/explores/courts.html',  
    'https://www.dpm.org.cn/explore/protects.html',  
    'https://www.dpm.org.cn/explore/cultures.html'  
]  

# 找到所有包含指定连接的元素
box_elements = driver.find_elements(By.CLASS_NAME, 'box')

# 找到所有包含 <a> 标签的 <div> 元素
div_elements = driver.find_elements(By.XPATH, '//div[contains(@class, "box")]//div[contains(@class, "div")]/a')
  
href_list = [div_element.get_attribute("href") for div_element in div_elements if div_element.get_attribute("href") not in unwanted_urls]  

# 逐个点击链接，用新标签页打开
type_num = 0
try:
    for link in href_list:
        # 获取当前窗口句柄
        current_window_handle = driver.current_window_handle

        type_num += 1

        artifact_type = link.split('/')[-1].split('.')[0]

        print('*'*50 + f'第 {type_num} 个文物类型——{type_mapping[artifact_type]}' + '*'*50)
        # 进一步提取信息
        artifact_details_crawler.main(link, type_num)

        driver.close()
        driver.switch_to.window(current_window_handle)

except KeyboardInterrupt:
    logging.error(f"程序终止：手动中止程序" + '\n\n' + '-'*80 + '\n')
    print("程序终止：手动中止程序")
    sys.exit(0)

except TimeoutError:
    logging.error(f"网页超时错误" + '\n\n' + '-'*80 + '\n')
    print("网页超时错误")
    sys.exit(0)

print('*'*50 + '文物已全部处理完成'+ '*'*50)

# 关闭浏览器
driver.quit()


