from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import threading
import time
import logging
import sys
import winsound
import multi-artifact_details_crawler

# 全局变量
NUM_THREADS = 25

# 线程局部变量
thread_local = threading.local()

def beep_for_duration(duration):
    end_time = time.time() + duration
    while time.time() < end_time:
        # 发出频率为1000Hz，持续时间为500毫秒的蜂鸣声
        winsound.Beep(1000, 500)
        time.sleep(1)  # 等待1秒

def process_artifact_type(link, type_num):
    try:
        multi-artifact_details_crawler.main(link, type_num)

    except Exception as e:
        logging.error(f"线程 {type_num} 发生异常：{e}", exc_info=True)

    finally:
        # 关闭浏览器
        driver.quit()


chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--log-level=3')  # 禁用除了错误信息之外的所有日志输出

# 找到所有包含指定连接的元素
driver = webdriver.Chrome(options=chrome_options)
driver.get('https://www.dpm.org.cn/explore/collections.html')
time.sleep(3)
unwanted_urls = [
    'https://www.dpm.org.cn/shuziduobaoge.html',
    'https://www.dpm.org.cn/explores/courts.html',
    'https://www.dpm.org.cn/explore/protects.html',
    'https://www.dpm.org.cn/explore/cultures.html'
]

# 找到所有包含 <a> 标签的 <div> 元素
div_elements = driver.find_elements(By.XPATH, '//div[contains(@class, "box")]//div[contains(@class, "div")]/a')
href_list = [div_element.get_attribute("href") for div_element in div_elements if div_element.get_attribute("href") not in unwanted_urls]

threads = []

try:
    for i, link in enumerate(href_list, start=1):
        thread = threading.Thread(target=process_artifact_type, args=(link, i))
        threads.append(thread)
        thread.start()

    # 等待所有线程完成
    for thread in threads:
        thread.join()

except KeyboardInterrupt:
    logging.error(f"程序终止：手动中止程序" + '\n\n' + '-'*80 + '\n')
    print("程序终止：手动中止程序")
    sys.exit(0)

except TimeoutError:
    logging.error(f"网页超时错误" + '\n\n' + '-'*80 + '\n')
    print("网页超时错误")
    sys.exit(0)

print('*'*50 + '文物已全部处理完成'+ '*'*50)

# 关闭浏览器
driver.quit()
